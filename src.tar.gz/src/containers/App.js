import React, { Component } from 'react'
import PostsContainer from './PostsContainer'

class App extends Component {
  render () {
    return (
      <div>
        <PostsContainer />
      </div>
    )
  }
}

export default App
