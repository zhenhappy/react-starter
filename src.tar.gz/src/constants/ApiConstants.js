export const POSTS_URL = `https://jsonplaceholder.typicode.com/posts`
