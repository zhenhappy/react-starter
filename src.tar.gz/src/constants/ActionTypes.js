export const LOAD_POSTS = 'LOAD_POSTS'
