import { combineReducers } from 'redux'
import post from './post'

export default combineReducers({
  post
})
